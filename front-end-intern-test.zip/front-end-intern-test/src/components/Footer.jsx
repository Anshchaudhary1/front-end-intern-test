import React from 'react'

export default function Footer(){
  return (
    <footer className="footer">
      <div className="container">
        <p>© 2025 EZ Labs. All rights reserved.</p>
      </div>
    </footer>
  )
}
